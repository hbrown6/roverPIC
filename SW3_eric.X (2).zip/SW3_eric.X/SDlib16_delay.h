#ifndef _SDLIB16_DELAY_H_
#define _SDLIB16_DELAY_H_
#include <xc.h>

/************************************************************
 *  2016 board version
* Delay routines only
*/

/* delay routines*/
void set_sys_clock(unsigned long val);
unsigned long get_sys_clock(void);
void set_pb_clock(unsigned long val);
unsigned long get_pb_clock(void);
void delay_ms(unsigned long val);
void delay_us(unsigned long val);



#endif //SDLIB16_DELAY_H